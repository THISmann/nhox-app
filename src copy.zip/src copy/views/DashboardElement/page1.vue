<template>
    <div>
      <h1 class="text-2xl font-bold">Page 1</h1>
      <p>This is the content for Page 1.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Page1',
  };
  </script>
  