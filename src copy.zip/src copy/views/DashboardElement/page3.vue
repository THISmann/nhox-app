<template>
    <div>
      <h1 class="text-2xl font-bold">Page 3</h1>
      <p>This is the content for Page 3.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Page3',
  };
  </script>
  